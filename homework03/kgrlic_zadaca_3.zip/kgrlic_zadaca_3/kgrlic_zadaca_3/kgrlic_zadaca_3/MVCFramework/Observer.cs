﻿namespace kgrlic_zadaca_3.MVCFramework
{
    abstract class Observer
    {
        public abstract void Update();
    }
}
