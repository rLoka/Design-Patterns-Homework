﻿using kgrlic_zadaca_2.Devices.Repair;

namespace kgrlic_zadaca_2.Devices
{
    partial class Device
    {
        public abstract void Accept(Visitor visitor);
    }
}
